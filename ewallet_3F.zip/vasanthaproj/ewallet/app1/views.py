from django.shortcuts import render
def index(request):
	return render(request, 'index.html')
def index1(request):
	return render(request, 'index1.html')
def sign(request):
	return render(request, 'sign.html')
def forgot(request):
	return render(request, 'forgot.html')
def register(request):
	return render(request, 'register.html')

def register(request):
	registered = False
	if request.method == 'POST':
		user_form = UserForm(data = request.POST)
		if user_form.is_valid():
			user = user_form.save()
			user.save()
			registered = True
			return render(request,'welcome.html',{'user_form':user_form,'registered':registered})
		else:
			print(user_form.errors)
	else:
		user_form = UserForm()
	return render(request,'register.html',{'user_form':user_form,'registered':registered})
def user_login(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')
		user = authenticate(username = username,password = password)
		a = UserProfileInfo.objects.filter(username = username).exists()
		b = UserProfileInfo.objects.filter(password = password).exists()
		if a and b:
			return HttpResponseRedirect(reverse('welcome'))
		else:
			print('some one tried to login and failed')
			print('They used username {} and password {}'.format(username,password))
			return HttpResponse('Invalid login details given')
	else:
		return render(request,'login.html')

# Create your views here.
