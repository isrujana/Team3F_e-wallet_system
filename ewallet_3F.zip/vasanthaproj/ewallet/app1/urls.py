from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
  	path('index1/', views.index1, name='index1'),
	path('index1/index', views.index, name='index'),
	path('index1/sign/',views.sign, name='sign'),
	path('index1/forgot/',views.forgot, name='forgot'),
	path('index1/register/',views.register, name='register'),
	path('index1/register/sign/',views.sign, name='sign'),
	path('index1/register/index',views.index, name='index'),
	path('index1/sign/index',views.index, name='index'),
	path('index1/sign/index1', views.index1, name='index1'),
	path('index1/forgot/index1', views.index1, name='index1'),
	path('index1/forgot/index',views.index, name='index'),
]
